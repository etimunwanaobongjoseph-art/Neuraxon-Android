# Neuraxon Android — Binance market data + optional live trading (v1.1)

## What this build does
- Native Android dashboard.
- Connects to Binance's public Spot market-data REST endpoint at `https://data-api.binance.vision` (no API key required).
- Downloads up to 100 one-hour klines for BTCUSDT, ETHUSDT, BNBUSDT, SOLUSDT and XRPUSDT.
- Ignores the currently open candle and feeds only fully closed candles to a Java port of the supplied 1,024-neuron Neuraxon brain and its online readout learning.
- Refreshes approximately every 60 seconds while the app is open and the bot is running. Since the strategy uses 1-hour candles, new decisions are only produced when a candle closes.
- Paper trading is simulated locally with a $10,000 starting balance, 1% equity risk per trade, ATR-based 1.5x stop distance, 2x reward/risk target, maximum aggregate notional of 1x paper equity, and a 3% session realized-loss stop.
- The first downloaded history is used only to warm up the brain; it does not create retroactive paper trades.
- Live trading is OFF by default and must be armed deliberately (see below). Paper trading keeps running alongside it.

## Live trading (opt-in)
Mode selector (top right): **Paper**, **Live: Binance Testnet (fake funds)**, or **Live: REAL MONEY**.

How to turn it on
1. Settings: paste an API key and secret, and set **Max per trade (USDT)** and **Session loss halt (USDT)** (defaults 15 and 5).
2. Pick a live mode. The app syncs time with Binance, checks the key (account read + a no-execution test order), and loads each pair's lot/price/min-notional rules.
3. Real money additionally requires typing `LIVE` in a confirmation dialog. Start with **Testnet** (keys from testnet.binance.vision; they differ from real keys).

What it does
- Spot, **long-only**: BUY opens a position, SELL closes one this app opened. It never shorts (the paper simulation still does).
- Entry: one market buy of up to *Max per trade*. Immediately afterwards it places an **exchange-side OCO** (take-profit LIMIT_MAKER + STOP_LOSS_LIMIT) at 1.5x ATR stop / 3x ATR target. If the OCO cannot be placed the position is sold at market straight away.
- Safety rails: max 3 open positions; refuses candles older than 15 minutes; skips trades whose stop distance is under 0.2% or over 15%; refuses if the cap is below the exchange minimum; halts new entries after the session loss limit; halts if an order's outcome is unknown (timeout / 5xx).
- **FLATTEN LIVE POSITIONS** cancels every stop/target, sells everything the app opened at market, and halts new entries.
- Keys live in memory only (cleared when the app closes) and the Settings dialog blocks screenshots. Use a trade-only key with **withdrawals disabled**, ideally on a small dedicated account.

Limits you should know about
- Positions and session P/L are in memory. If the app is closed, open positions stay protected by their exchange-side OCO, but the app forgets them. Check Binance, and cancel/close them there.
- The app only reconciles stop/target fills while the bot is running (about once a minute).
- A STOP_LOSS_LIMIT can trigger and then not fill in a fast crash; that is a property of stop-limit orders.
- Fees paid in BNB are not counted in P/L. Fees in the base or quote asset are.
- Binance may refuse connections from some countries (HTTP 451). Then the app cannot arm live trading.
- **The signal is experimental. It has no demonstrated edge, and nothing here is financial advice.** Run Testnet and paper for a long time first.

## What was tested (and what was not)
Tested on a desktop JVM with stand-in Android classes and a mock exchange that checks HMAC signatures, parameter precision and order rules: request signing (also against the worked example in Binance's docs), time sync, symbol filter rounding, market buy/sell parsing including fees, OCO placement/cancel/status, error handling, and the entry/exit/halt logic in `MainActivity`.
**Not tested:** the real Android build, the UI, and any real Binance server (including Testnet). Treat the first Testnet run as the real test.

## Important limitations
- Paper positions and P/L are in-memory and reset when the app process is restarted. This is a simulation, not a broker statement.
- Stops and targets are evaluated on each newly closed 1-hour candle, not tick-by-tick.
- The app uses Binance Spot USDT pairs. Public data availability may vary by region/network and Binance service availability.
- This is an experimental signal engine, not a validated profitable strategy or financial advice. Test and inspect results before relying on it.
- The supplied TypeScript brain's neural inference and online readout update have been ported to Java for Android. The separate TypeScript file is retained in app assets as the original reference.

## Build on GitHub Actions from a phone
Upload this entire project as a ZIP named `NeuraxonAndroid-Source.zip` to the repository root. The repository's existing workflow should extract it and run `gradle -p NeuraxonAndroid assembleDebug`. Download the resulting `neuraxon-debug-apk` artifact from the Actions run.
