package com.neuraxon.app;

import java.util.ArrayList;
import java.util.List;

/** Java port of the supplied Neuraxon 1,024-neuron brain's inference and online readout learning. */
final class NeuraxonEngine {
    static final class Candle {
        long time; double open, high, low, close, volume;
        Candle(long t,double o,double h,double l,double c,double v){time=t;open=o;high=h;low=l;close=c;volume=v;}
    }
    static final class Result { final String signal; final double confidence; final double atr; Result(String s,double c,double a){signal=s;confidence=c;atr=a;} }
    private static final int N=1024, INPUT=164, CONTROL=90, OUTPUT=770, K=16;
    private final float[] x=new float[N], inW=new float[INPUT], weights=new float[N*K], readout=new float[OUTPUT];
    private final int[] links=new int[N*K];
    private float[] lastSnapshot; private double lastPred; private Double prevClose=null; private double prevVol=1e-3;
    private final List<Candle> candles=new ArrayList<>();
    private long rng;
    NeuraxonEngine(int seed){rng=seed; for(int i=0;i<N;i++)for(int k=0;k<K;k++){int z=i*K+k;links[z]=(int)(next()*N);weights[z]=(float)(signed()*0.45);} for(int i=0;i<INPUT;i++)inW[i]=(float)signed();}
    private double next(){rng=(rng*1664525L+1013904223L)&0xffffffffL;return rng/4294967296.0;}
    private double signed(){return next()*2-1;}
    private void learn(double target){if(lastSnapshot==null)return;double norm=1e-6;for(float v:lastSnapshot)norm+=v*v;double err=target-lastPred;for(int j=0;j<OUTPUT;j++)readout[j]+=(float)((0.05*err*lastSnapshot[j])/norm);}
    Result onClosedCandle(Candle c){
        candles.add(c); if(candles.size()>500)candles.remove(0);
        if(prevClose!=null){double r=(c.close-prevClose)/prevClose/prevVol;learn(Math.max(-1,Math.min(1,r/2)));} prevClose=c.close;
        if(candles.size()<50)return new Result("WARMING UP",0,0);
        double[] closes=new double[candles.size()];for(int i=0;i<closes.length;i++)closes[i]=candles.get(i).close;
        double last=closes[closes.length-1]; double[] rets=new double[20];double mean=0;
        for(int i=0;i<20;i++){double a=closes[closes.length-20+i-1],b=closes[closes.length-20+i];rets[i]=(b-a)/a;mean+=rets[i];} mean/=20;
        double variance=0;for(double r:rets)variance+=(r-mean)*(r-mean);double vol=Math.sqrt(variance/20);if(vol==0||Double.isNaN(vol))vol=1e-6;prevVol=vol;
        double avgVol=0;for(int i=candles.size()-20;i<candles.size();i++)avgVol+=candles.get(i).volume;avgVol=avgVol/20;if(avgVol==0)avgVol=1;
        double[] f=new double[8];f[0]=clip(ret(closes,1)/vol);f[1]=clip(ret(closes,5)/(vol*Math.sqrt(5)));f[2]=clip(ret(closes,20)/(vol*Math.sqrt(20)));
        f[3]=(rsi(closes)-50)/25;f[4]=clip((emaTail(closes,12)-emaTail(closes,26))/last/vol);f[5]=clip(vol*100);f[6]=clip(c.volume/avgVol-1);f[7]=1;
        float[] nx=new float[N];for(int i=0;i<N;i++){double sum=0;for(int k=0;k<K;k++){int z=i*K+k;sum+=weights[z]*x[links[z]];}if(i<INPUT)sum+=inW[i]*f[i%8];nx[i]=(float)(0.7*x[i]+0.3*Math.tanh(sum));}System.arraycopy(nx,0,x,0,N);
        double out=0;for(int j=0;j<OUTPUT;j++)out+=readout[j]*x[INPUT+CONTROL+j];double pred=Math.tanh(out);double gate=0;for(int j=0;j<CONTROL;j++)gate+=Math.abs(x[INPUT+j]);gate=Math.min(1,gate/CONTROL*2);double confidence=Math.abs(pred)*(0.5+0.5*gate);
        lastSnapshot=new float[OUTPUT];System.arraycopy(x,INPUT+CONTROL,lastSnapshot,0,OUTPUT);lastPred=pred;
        double atrValue=0; for(int i=candles.size()-14;i<candles.size();i++){Candle q=candles.get(i),p=candles.get(i-1);atrValue+=Math.max(q.high-q.low,Math.max(Math.abs(q.high-p.close),Math.abs(q.low-p.close)));} atrValue/=14;
        String signal=confidence<0.25?"HOLD":pred>0?"BUY":"SELL";return new Result(signal,confidence,atrValue);
    }
    private static double ret(double[] c,int k){return (c[c.length-1]-c[c.length-1-k])/c[c.length-1-k];}
    private static double clip(double v){return Math.max(-3,Math.min(3,v));}
    private static double emaTail(double[] a,int p){int start=Math.max(0,a.length-p);double e=a[start],alpha=2.0/(p+1);for(int i=start+1;i<a.length;i++)e=alpha*a[i]+(1-alpha)*e;return e;}
    private static double rsi(double[] c){double g=0,l=0;for(int i=c.length-14;i<c.length;i++){double d=c[i]-c[i-1];if(d>=0)g+=d;else l-=d;}return l==0?100:100-100/(1+g/l);}
}
