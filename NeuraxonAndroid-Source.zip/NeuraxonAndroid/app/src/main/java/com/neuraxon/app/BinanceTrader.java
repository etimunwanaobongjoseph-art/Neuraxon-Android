package com.neuraxon.app;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

/**
 * Minimal Binance Spot REST client used for live trading.
 * Signed requests (HMAC-SHA256), symbol filters, market orders, exchange-side OCO exits.
 * The API secret is only held in memory and is never logged or included in error text.
 */
final class BinanceTrader {
    static final String LIVE_URL = "https://api.binance.com";
    static final String TESTNET_URL = "https://testnet.binance.vision";

    /** unknown = true means a POST/DELETE may or may not have executed (timeout / 5xx). */
    static final class ApiException extends Exception {
        final int http, code;
        final boolean unknown;
        ApiException(int http, int code, String msg, boolean unknown) {
            super(msg);
            this.http = http;
            this.code = code;
            this.unknown = unknown;
        }
    }

    static final class Rules {
        String baseAsset, quoteAsset;
        BigDecimal stepSize, minQty, tickSize, minNotional;

        BigDecimal floorQty(BigDecimal q) { return floorTo(q, stepSize); }
        BigDecimal floorPrice(BigDecimal p) { return floorTo(p, tickSize); }

        private static BigDecimal floorTo(BigDecimal v, BigDecimal step) {
            int dec = Math.max(0, step.stripTrailingZeros().scale());
            return v.divideToIntegralValue(step).multiply(step).setScale(dec, RoundingMode.DOWN);
        }
    }

    static final class Fill {
        double avgPrice;       // average execution price
        BigDecimal netQty;     // executed base quantity minus any fee paid in the base asset
        double quote;          // cumulative quote amount (spent on a BUY, gross proceeds on a SELL)
        double feeQuote;       // fees paid in the quote asset
    }

    static final class Oco {
        long listId;
        final List<Long> orderIds = new ArrayList<>();
    }

    private final String baseUrl, apiKey, secret;
    private volatile long timeOffset = 0;
    private final Map<String, Rules> rulesCache = new HashMap<>();

    BinanceTrader(String baseUrl, String apiKey, String secret) {
        this.baseUrl = baseUrl;
        this.apiKey = apiKey.trim();
        this.secret = secret.trim();
    }

    long serverNow() { return System.currentTimeMillis() + timeOffset; }

    void syncTime() throws ApiException {
        try {
            JSONObject o = new JSONObject(call("GET", "/api/v3/time", new LinkedHashMap<String, String>(), false));
            timeOffset = o.getLong("serverTime") - System.currentTimeMillis();
        } catch (ApiException e) {
            throw e;
        } catch (Exception e) {
            throw new ApiException(0, 0, "Bad time response: " + e.getMessage(), false);
        }
    }

    // ---------------------------------------------------------------- account

    /** Confirms the key works and can place orders, without sending a real order. */
    String verify(String symbol, double quoteUsdt) throws ApiException {
        try {
            JSONObject acct = new JSONObject(call("GET", "/api/v3/account", new LinkedHashMap<String, String>(), true));
            if (!acct.optBoolean("canTrade", false)) {
                throw new ApiException(0, 0, "This account cannot trade. Enable Spot trading on the API key.", false);
            }
            Map<String, String> p = new LinkedHashMap<>();
            p.put("symbol", symbol);
            p.put("side", "BUY");
            p.put("type", "MARKET");
            p.put("quoteOrderQty", fmt(BigDecimal.valueOf(quoteUsdt).setScale(2, RoundingMode.DOWN)));
            call("POST", "/api/v3/order/test", p, true); // validates permissions and filters; never reaches the matching engine
            int open = new JSONArray(call("GET", "/api/v3/openOrderList", new LinkedHashMap<String, String>(), true)).length();
            return "Keys OK. Free USDT: " + String.format(Locale.US, "%.2f", balanceOf(acct, "USDT"))
                    + (open > 0 ? ". Note: " + open + " open order list(s) already exist on this account; this app does not manage them." : ".");
        } catch (ApiException e) {
            throw e;
        } catch (Exception e) {
            throw new ApiException(0, 0, "Unexpected response: " + e.getMessage(), false);
        }
    }

    double freeBalance(String asset) throws ApiException {
        try {
            return balanceOf(new JSONObject(call("GET", "/api/v3/account", new LinkedHashMap<String, String>(), true)), asset);
        } catch (ApiException e) {
            throw e;
        } catch (Exception e) {
            throw new ApiException(0, 0, "Bad account response: " + e.getMessage(), false);
        }
    }

    private static double balanceOf(JSONObject acct, String asset) throws Exception {
        JSONArray b = acct.getJSONArray("balances");
        for (int i = 0; i < b.length(); i++) {
            JSONObject o = b.getJSONObject(i);
            if (asset.equals(o.getString("asset"))) return Double.parseDouble(o.getString("free"));
        }
        return 0;
    }

    // ------------------------------------------------------------ symbol rules

    Rules rules(String symbol) throws ApiException {
        Rules cached = rulesCache.get(symbol);
        if (cached != null) return cached;
        try {
            Map<String, String> p = new LinkedHashMap<>();
            p.put("symbol", symbol);
            JSONObject root = new JSONObject(call("GET", "/api/v3/exchangeInfo", p, false));
            JSONObject s = root.getJSONArray("symbols").getJSONObject(0);
            if (!"TRADING".equals(s.optString("status"))) {
                throw new ApiException(0, 0, symbol + " is not currently trading.", false);
            }
            Rules r = new Rules();
            r.baseAsset = s.getString("baseAsset");
            r.quoteAsset = s.getString("quoteAsset");
            JSONArray f = s.getJSONArray("filters");
            for (int i = 0; i < f.length(); i++) {
                JSONObject o = f.getJSONObject(i);
                String t = o.getString("filterType");
                if (t.equals("LOT_SIZE")) {
                    r.stepSize = new BigDecimal(o.getString("stepSize"));
                    r.minQty = new BigDecimal(o.getString("minQty"));
                } else if (t.equals("PRICE_FILTER")) {
                    r.tickSize = new BigDecimal(o.getString("tickSize"));
                } else if (t.equals("NOTIONAL") || t.equals("MIN_NOTIONAL")) {
                    r.minNotional = new BigDecimal(o.getString("minNotional"));
                }
            }
            if (r.stepSize == null || r.minQty == null || r.tickSize == null || r.minNotional == null
                    || r.stepSize.signum() <= 0 || r.tickSize.signum() <= 0) {
                throw new ApiException(0, 0, "Missing trading filters for " + symbol, false);
            }
            rulesCache.put(symbol, r);
            return r;
        } catch (ApiException e) {
            throw e;
        } catch (Exception e) {
            throw new ApiException(0, 0, "Bad exchange info for " + symbol + ": " + e.getMessage(), false);
        }
    }

    // ------------------------------------------------------------------ orders

    Fill marketBuyQuote(String symbol, double quoteUsdt) throws ApiException {
        Rules r = rules(symbol);
        Map<String, String> p = new LinkedHashMap<>();
        p.put("symbol", symbol);
        p.put("side", "BUY");
        p.put("type", "MARKET");
        p.put("quoteOrderQty", fmt(BigDecimal.valueOf(quoteUsdt).setScale(2, RoundingMode.DOWN)));
        p.put("newOrderRespType", "FULL");
        return parseFill(call("POST", "/api/v3/order", p, true), r);
    }

    Fill marketSell(String symbol, BigDecimal qty) throws ApiException {
        Rules r = rules(symbol);
        Map<String, String> p = new LinkedHashMap<>();
        p.put("symbol", symbol);
        p.put("side", "SELL");
        p.put("type", "MARKET");
        p.put("quantity", fmt(r.floorQty(qty)));
        p.put("newOrderRespType", "FULL");
        return parseFill(call("POST", "/api/v3/order", p, true), r);
    }

    /** Exchange-side exit: take-profit (LIMIT_MAKER) above, stop-loss-limit below. */
    Oco placeOco(String symbol, BigDecimal qty, BigDecimal target, BigDecimal stop) throws ApiException {
        Rules r = rules(symbol);
        BigDecimal tp = r.floorPrice(target);
        BigDecimal sp = r.floorPrice(stop);
        BigDecimal sl = r.floorPrice(stop.multiply(new BigDecimal("0.998"))); // limit leg 0.2% under the trigger
        if (sl.compareTo(sp) >= 0) sl = sp.subtract(r.tickSize);
        if (sl.signum() <= 0 || tp.compareTo(sp) <= 0) {
            throw new ApiException(0, 0, "Stop/target prices are not valid for " + symbol, false);
        }
        Map<String, String> p = new LinkedHashMap<>();
        p.put("symbol", symbol);
        p.put("side", "SELL");
        p.put("quantity", fmt(qty));
        p.put("aboveType", "LIMIT_MAKER");
        p.put("abovePrice", fmt(tp));
        p.put("belowType", "STOP_LOSS_LIMIT");
        p.put("belowStopPrice", fmt(sp));
        p.put("belowPrice", fmt(sl));
        p.put("belowTimeInForce", "GTC");
        try {
            JSONObject o = new JSONObject(call("POST", "/api/v3/orderList/oco", p, true));
            Oco oco = new Oco();
            oco.listId = o.getLong("orderListId");
            JSONArray orders = o.getJSONArray("orders");
            for (int i = 0; i < orders.length(); i++) oco.orderIds.add(orders.getJSONObject(i).getLong("orderId"));
            return oco;
        } catch (ApiException e) {
            throw e;
        } catch (Exception e) {
            // The list may have been created even though the reply was unreadable.
            throw new ApiException(0, 0, "Unreadable OCO response: " + e.getMessage(), true);
        }
    }

    void cancelOco(String symbol, long listId) throws ApiException {
        Map<String, String> p = new LinkedHashMap<>();
        p.put("symbol", symbol);
        p.put("orderListId", String.valueOf(listId));
        call("DELETE", "/api/v3/orderList", p, true);
    }

    /** EXECUTING while the exit is still live; ALL_DONE once a leg filled or the list was cancelled/expired. */
    String ocoStatus(String symbol, long listId) throws ApiException {
        Map<String, String> p = new LinkedHashMap<>();
        p.put("orderListId", String.valueOf(listId));
        try {
            return new JSONObject(call("GET", "/api/v3/orderList", p, true)).getString("listOrderStatus");
        } catch (ApiException e) {
            throw e;
        } catch (Exception e) {
            throw new ApiException(0, 0, "Bad order list response: " + e.getMessage(), false);
        }
    }

    /** Returns {net quote proceeds, number of trades} for the given sell orders. */
    double[] sellProceeds(String symbol, List<Long> orderIds) throws ApiException {
        Rules r = rules(symbol);
        double total = 0;
        int trades = 0;
        try {
            for (Long id : orderIds) {
                Map<String, String> p = new LinkedHashMap<>();
                p.put("symbol", symbol);
                p.put("orderId", String.valueOf(id));
                JSONArray arr = new JSONArray(call("GET", "/api/v3/myTrades", p, true));
                for (int i = 0; i < arr.length(); i++) {
                    JSONObject t = arr.getJSONObject(i);
                    total += Double.parseDouble(t.getString("quoteQty"));
                    if (r.quoteAsset.equals(t.optString("commissionAsset"))) {
                        total -= Double.parseDouble(t.getString("commission"));
                    }
                    trades++;
                }
            }
        } catch (ApiException e) {
            throw e;
        } catch (Exception e) {
            throw new ApiException(0, 0, "Bad trades response: " + e.getMessage(), false);
        }
        return new double[]{total, trades};
    }

    // ----------------------------------------------------------------- helpers

    private Fill parseFill(String json, Rules r) throws ApiException {
        try {
            JSONObject o = new JSONObject(json);
            BigDecimal exec = new BigDecimal(o.getString("executedQty"));
            BigDecimal quote = new BigDecimal(o.getString("cummulativeQuoteQty"));
            if (exec.signum() <= 0) {
                throw new ApiException(0, 0, "Order was not filled (status " + o.optString("status") + ").", false);
            }
            BigDecimal feeBase = BigDecimal.ZERO, feeQuote = BigDecimal.ZERO;
            JSONArray fills = o.optJSONArray("fills");
            if (fills != null) {
                for (int i = 0; i < fills.length(); i++) {
                    JSONObject f = fills.getJSONObject(i);
                    String asset = f.getString("commissionAsset");
                    BigDecimal fee = new BigDecimal(f.getString("commission"));
                    if (asset.equals(r.baseAsset)) feeBase = feeBase.add(fee);
                    else if (asset.equals(r.quoteAsset)) feeQuote = feeQuote.add(fee);
                }
            }
            Fill f = new Fill();
            f.avgPrice = quote.divide(exec, 8, RoundingMode.HALF_UP).doubleValue();
            f.netQty = exec.subtract(feeBase);
            f.quote = quote.doubleValue();
            f.feeQuote = feeQuote.doubleValue();
            return f;
        } catch (ApiException e) {
            throw e;
        } catch (Exception e) {
            // The order was accepted by the exchange; we just cannot read the result.
            throw new ApiException(0, 0, "Unreadable order response: " + e.getMessage(), true);
        }
    }

    static String fmt(BigDecimal v) { return v.stripTrailingZeros().toPlainString(); }

    String sign(String payload) {
        try {
            Mac mac = Mac.getInstance("HmacSHA256");
            mac.init(new SecretKeySpec(secret.getBytes("UTF-8"), "HmacSHA256"));
            byte[] raw = mac.doFinal(payload.getBytes("UTF-8"));
            StringBuilder sb = new StringBuilder(raw.length * 2);
            for (byte b : raw) sb.append(String.format(Locale.US, "%02x", b));
            return sb.toString();
        } catch (Exception e) {
            throw new IllegalStateException("Could not sign request");
        }
    }

    private static String enc(String s) {
        try {
            return URLEncoder.encode(s, "UTF-8");
        } catch (UnsupportedEncodingException e) {
            throw new IllegalStateException(e);
        }
    }

    private static String read(InputStream in) throws IOException {
        if (in == null) return "";
        StringBuilder sb = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(in, "UTF-8"))) {
            String line;
            while ((line = br.readLine()) != null) sb.append(line);
        }
        return sb.toString();
    }

    private String call(String method, String path, Map<String, String> params, boolean signed) throws ApiException {
        Map<String, String> p = new LinkedHashMap<>(params);
        if (signed) {
            p.put("recvWindow", "5000");
            p.put("timestamp", String.valueOf(serverNow()));
        }
        StringBuilder q = new StringBuilder();
        for (Map.Entry<String, String> e : p.entrySet()) {
            if (q.length() > 0) q.append('&');
            q.append(enc(e.getKey())).append('=').append(enc(e.getValue()));
        }
        if (signed) {
            String signature = sign(q.toString()); // sign BEFORE appending the signature parameter
            q.append("&signature=").append(signature);
        }
        boolean mutating = method.equals("POST") || method.equals("DELETE");
        boolean inBody = method.equals("POST");
        HttpURLConnection c = null;
        try {
            String url = baseUrl + path + ((inBody || q.length() == 0) ? "" : "?" + q);
            c = (HttpURLConnection) new URL(url).openConnection();
            c.setRequestMethod(method);
            c.setConnectTimeout(12000);
            c.setReadTimeout(12000);
            c.setRequestProperty("User-Agent", "Neuraxon-Android/2.0");
            if (signed) c.setRequestProperty("X-MBX-APIKEY", apiKey);
            if (inBody) {
                byte[] body = q.toString().getBytes("UTF-8");
                c.setDoOutput(true);
                c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
                c.setFixedLengthStreamingMode(body.length);
                try (OutputStream os = c.getOutputStream()) { os.write(body); }
            }
            int code = c.getResponseCode();
            if (code >= 200 && code < 300) return read(c.getInputStream());
            String text = read(c.getErrorStream());
            int bcode = 0;
            String msg = "HTTP " + code;
            try {
                JSONObject j = new JSONObject(text);
                bcode = j.optInt("code", 0);
                msg = j.optString("msg", msg);
            } catch (Exception ignored) { }
            throw new ApiException(code, bcode, msg + " (code " + bcode + ")", mutating && code >= 500);
        } catch (ApiException e) {
            throw e;
        } catch (IOException e) {
            throw new ApiException(0, 0, "Network error: " + e.getMessage(), mutating);
        } finally {
            if (c != null) c.disconnect();
        }
    }
}
