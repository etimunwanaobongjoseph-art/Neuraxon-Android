/**
 * neuraxon-mini-bot.ts
 * Dependency-free mini trading engine:
 *   Candles -> NeuraxonBrain (1,024 neurons: 164 input / 90 control / 770 output)
 *           -> Signal (BUY / SELL / HOLD) -> RiskManager -> Broker
 *
 * Defaults to PAPER trading. To trade live, implement the `Broker` interface
 * for your exchange (see LiveBrokerTemplate at the bottom) and pass it to TradingBot.
 *
 * NOT financial advice. Backtest and paper trade first. You can lose money.
 */

// ---------- Types ----------
export interface Candle {
  time: number; open: number; high: number; low: number; close: number; volume: number;
}
export type Signal = "BUY" | "SELL" | "HOLD";
export type Side = "LONG" | "SHORT";

/** Plug any external brain in here (e.g. the real Qubic BPP-9000 brain). Called once per closed candle. */
export interface SignalSource {
  next(candle: Candle): Signal;
}

export interface Position {
  side: Side; entry: number; qty: number; stop: number; target: number;
}

export interface Broker {
  getEquity(): number;
  open(side: Side, qty: number, price: number): Promise<void>;
  close(position: Position, price: number): Promise<void>;
}

export interface BotConfig {
  warmup: number;          // candles before trading starts
  threshold: number;       // min confidence (0..1) to act
  riskPerTrade: number;    // fraction of equity risked per trade, e.g. 0.01 = 1%
  stopAtrMult: number;     // stop distance = ATR * this
  rewardRisk: number;      // take-profit = stop distance * this
  allowShort: boolean;
  maxDailyLoss: number;    // fraction of day-start equity, e.g. 0.03 = 3%
  cooldownCandles: number; // wait after closing a trade
}

export const DEFAULT_CONFIG: BotConfig = {
  warmup: 50,
  threshold: 0.25,
  riskPerTrade: 0.01,
  stopAtrMult: 1.5,
  rewardRisk: 2,
  allowShort: true,
  maxDailyLoss: 0.03,
  cooldownCandles: 3,
};

// ---------- Brain ----------
class RNG {
  constructor(private s: number) {}
  next(): number { this.s = (this.s * 1664525 + 1013904223) >>> 0; return this.s / 4294967296; }
  signed(): number { return this.next() * 2 - 1; }
}

export class NeuraxonBrain {
  static readonly N = 1024;
  static readonly INPUT = 164;
  static readonly CONTROL = 90;
  static readonly OUTPUT = 770;
  static readonly FEATURES = 8;
  private readonly CONTROL_START = NeuraxonBrain.INPUT;
  private readonly OUTPUT_START = NeuraxonBrain.INPUT + NeuraxonBrain.CONTROL;

  private x = new Float32Array(NeuraxonBrain.N);
  private inW = new Float32Array(NeuraxonBrain.INPUT);
  private links: Int32Array;   // 16 incoming connections per neuron
  private weights: Float32Array;
  private readout = new Float32Array(NeuraxonBrain.OUTPUT);
  private readonly K = 16;
  private readonly leak = 0.3;
  private readonly lr = 0.05;

  private lastSnapshot: Float32Array | null = null;
  private lastPred = 0;

  constructor(seed = 1337) {
    const rng = new RNG(seed);
    const N = NeuraxonBrain.N;
    this.links = new Int32Array(N * this.K);
    this.weights = new Float32Array(N * this.K);
    for (let i = 0; i < N; i++) {
      for (let k = 0; k < this.K; k++) {
        this.links[i * this.K + k] = Math.floor(rng.next() * N);
        this.weights[i * this.K + k] = rng.signed() * 0.45;
      }
    }
    for (let i = 0; i < NeuraxonBrain.INPUT; i++) this.inW[i] = rng.signed();
  }

  /** Step the network on a feature vector; returns prediction in [-1, 1] and confidence in [0, 1]. */
  think(features: number[]): { pred: number; confidence: number } {
    const N = NeuraxonBrain.N;
    const next = new Float32Array(N);
    for (let i = 0; i < N; i++) {
      let sum = 0;
      for (let k = 0; k < this.K; k++) sum += this.weights[i * this.K + k] * this.x[this.links[i * this.K + k]];
      if (i < NeuraxonBrain.INPUT) sum += this.inW[i] * features[i % NeuraxonBrain.FEATURES];
      next[i] = (1 - this.leak) * this.x[i] + this.leak * Math.tanh(sum);
    }
    this.x = next;

    let out = 0;
    for (let j = 0; j < NeuraxonBrain.OUTPUT; j++) out += this.readout[j] * this.x[this.OUTPUT_START + j];
    const pred = Math.tanh(out);

    // Control neurons modulate confidence (how "sure" the network is overall)
    let gate = 0;
    for (let c = 0; c < NeuraxonBrain.CONTROL; c++) gate += Math.abs(this.x[this.CONTROL_START + c]);
    gate = Math.min(1, gate / NeuraxonBrain.CONTROL * 2);

    this.lastSnapshot = this.x.slice(this.OUTPUT_START);
    this.lastPred = pred;
    return { pred, confidence: Math.abs(pred) * (0.5 + 0.5 * gate) };
  }

  /** Online learning: after the next candle, teach the readout what actually happened. target in [-1, 1]. */
  learn(target: number): void {
    if (!this.lastSnapshot) return;
    const s = this.lastSnapshot;
    let norm = 1e-6;
    for (let j = 0; j < s.length; j++) norm += s[j] * s[j];
    const err = target - this.lastPred;
    for (let j = 0; j < s.length; j++) this.readout[j] += (this.lr * err * s[j]) / norm;
  }
}

// ---------- Indicators / features ----------
const ema = (v: number[], p: number): number => {
  const a = 2 / (p + 1); let e = v[0];
  for (let i = 1; i < v.length; i++) e = a * v[i] + (1 - a) * e;
  return e;
};

function rsi(closes: number[], p = 14): number {
  let g = 0, l = 0;
  for (let i = closes.length - p; i < closes.length; i++) {
    const d = closes[i] - closes[i - 1];
    d >= 0 ? (g += d) : (l -= d);
  }
  return l === 0 ? 100 : 100 - 100 / (1 + g / l);
}

function atr(c: Candle[], p = 14): number {
  let s = 0;
  for (let i = c.length - p; i < c.length; i++) {
    s += Math.max(c[i].high - c[i].low, Math.abs(c[i].high - c[i - 1].close), Math.abs(c[i].low - c[i - 1].close));
  }
  return s / p;
}

function buildFeatures(c: Candle[]): { f: number[]; atr: number; vol: number } {
  const closes = c.map(x => x.close);
  const n = closes.length;
  const last = closes[n - 1];
  const ret = (k: number) => (last - closes[n - 1 - k]) / closes[n - 1 - k];
  const rets: number[] = [];
  for (let i = n - 20; i < n; i++) rets.push((closes[i] - closes[i - 1]) / closes[i - 1]);
  const mean = rets.reduce((a, b) => a + b, 0) / rets.length;
  const vol = Math.sqrt(rets.reduce((a, b) => a + (b - mean) ** 2, 0) / rets.length) || 1e-6;
  const avgVol = c.slice(-20).reduce((a, b) => a + b.volume, 0) / 20 || 1;
  const clip = (v: number) => Math.max(-3, Math.min(3, v));
  const f = [
    clip(ret(1) / vol),
    clip(ret(5) / (vol * Math.sqrt(5))),
    clip(ret(20) / (vol * Math.sqrt(20))),
    (rsi(closes) - 50) / 25,
    clip((ema(closes.slice(-12), 12) - ema(closes.slice(-26), 26)) / last / vol),
    clip(vol * 100),
    clip(c[n - 1].volume / avgVol - 1),
    1,
  ];
  return { f, atr: atr(c), vol };
}

// ---------- Paper broker ----------
export class PaperBroker implements Broker {
  constructor(private equity = 10_000, private feeRate = 0.0006) {}
  getEquity() { return this.equity; }
  async open(_s: Side, qty: number, price: number) { this.equity -= qty * price * this.feeRate; }
  async close(p: Position, price: number) {
    const pnl = (p.side === "LONG" ? price - p.entry : p.entry - price) * p.qty;
    this.equity += pnl - p.qty * price * this.feeRate;
  }
}

// ---------- Bot ----------
export class TradingBot {
  private candles: Candle[] = [];
  private position: Position | null = null;
  private cooldown = 0;
  private dayKey = "";
  private dayStartEquity: number;
  private prevClose: number | null = null;
  private prevVol = 1e-3;
  readonly brain = new NeuraxonBrain();
  readonly log: string[] = [];

  constructor(
    private broker: Broker = new PaperBroker(),
    private cfg: BotConfig = DEFAULT_CONFIG,
    private source?: SignalSource,
  ) {
    this.dayStartEquity = broker.getEquity();
  }

  /** Feed one closed candle. Call this from your exchange websocket/poller. */
  async onCandle(candle: Candle): Promise<Signal> {
    this.candles.push(candle);
    if (this.candles.length > 500) this.candles.shift();

    // reset daily loss tracker
    const day = new Date(candle.time).toISOString().slice(0, 10);
    if (day !== this.dayKey) { this.dayKey = day; this.dayStartEquity = this.broker.getEquity(); }

    // teach the brain what the last candle actually did
    if (this.prevClose !== null && !this.source) {
      const r = (candle.close - this.prevClose) / this.prevClose / this.prevVol;
      this.brain.learn(Math.max(-1, Math.min(1, r / 2)));
    }
    this.prevClose = candle.close;

    // manage open position (stop / target)
    if (this.position) {
      const p = this.position;
      const hitStop = p.side === "LONG" ? candle.low <= p.stop : candle.high >= p.stop;
      const hitTarget = p.side === "LONG" ? candle.high >= p.target : candle.low <= p.target;
      if (hitStop || hitTarget) await this.exit(hitStop ? p.stop : p.target, hitStop ? "STOP" : "TARGET");
    }

    if (this.candles.length < this.cfg.warmup) return "HOLD";

    const { f, atr: a, vol } = buildFeatures(this.candles);
    this.prevVol = vol;
    let signal: Signal;
    if (this.source) {
      signal = this.source.next(candle);
    } else {
      const { pred, confidence } = this.brain.think(f);
      signal = confidence < this.cfg.threshold ? "HOLD" : pred > 0 ? "BUY" : "SELL";
    }

    if (this.cooldown > 0) this.cooldown--;

    // reverse on opposite signal
    if (this.position && signal !== "HOLD") {
      const opposite = (this.position.side === "LONG" && signal === "SELL") ||
                       (this.position.side === "SHORT" && signal === "BUY");
      if (opposite) await this.exit(candle.close, "REVERSE");
    }

    // open new position
    if (!this.position && signal !== "HOLD" && this.cooldown === 0 && !this.dailyLossHit()) {
      const side: Side = signal === "BUY" ? "LONG" : "SHORT";
      if (side === "SHORT" && !this.cfg.allowShort) return signal;
      const stopDist = a * this.cfg.stopAtrMult;
      const equity = this.broker.getEquity();
      const qty = (equity * this.cfg.riskPerTrade) / stopDist;
      // never use more than 1x equity notional
      const safeQty = Math.min(qty, equity / candle.close);
      if (safeQty > 0 && isFinite(safeQty)) {
        const dir = side === "LONG" ? 1 : -1;
        this.position = {
          side, entry: candle.close, qty: safeQty,
          stop: candle.close - dir * stopDist,
          target: candle.close + dir * stopDist * this.cfg.rewardRisk,
        };
        await this.broker.open(side, safeQty, candle.close);
        this.log.push(`${new Date(candle.time).toISOString()} OPEN ${side} @ ${candle.close.toFixed(2)} qty ${safeQty.toFixed(4)}`);
      }
    }
    return signal;
  }

  private dailyLossHit(): boolean {
    return this.broker.getEquity() < this.dayStartEquity * (1 - this.cfg.maxDailyLoss);
  }

  private async exit(price: number, reason: string) {
    if (!this.position) return;
    await this.broker.close(this.position, price);
    this.log.push(`CLOSE ${this.position.side} @ ${price.toFixed(2)} (${reason}) equity ${this.broker.getEquity().toFixed(2)}`);
    this.position = null;
    this.cooldown = this.cfg.cooldownCandles;
  }

  get equity() { return this.broker.getEquity(); }
}

// ---------- Live broker template (fill in for your exchange) ----------
export class LiveBrokerTemplate implements Broker {
  getEquity(): number { throw new Error("Fetch account equity from your exchange API"); }
  async open(side: Side, qty: number, price: number): Promise<void> {
    // e.g. POST /order { symbol, side: side === "LONG" ? "BUY" : "SELL", type: "MARKET", quantity: qty }
    throw new Error("Implement order placement");
  }
  async close(position: Position, price: number): Promise<void> {
    // e.g. place the opposite market order for position.qty
    throw new Error("Implement position close");
  }
}

// ---------- Demo: run `npx tsx neuraxon-mini-bot.ts` ----------
async function demo() {
  const bot = new TradingBot();
  let price = 100;
  let t = Date.UTC(2026, 0, 1);
  for (let i = 0; i < 3000; i++) {
    const drift = Math.sin(i / 60) * 0.15; // synthetic trending/cycling market
    const open = price;
    price = Math.max(1, price * (1 + drift / 100 + (Math.random() - 0.5) * 0.01));
    await bot.onCandle({
      time: (t += 3_600_000), open,
      high: Math.max(open, price) * 1.002, low: Math.min(open, price) * 0.998,
      close: price, volume: 100 + Math.random() * 50,
    });
  }
  console.log(bot.log.slice(-10).join("\n"));
  console.log("Final equity:", bot.equity.toFixed(2));
}
if (typeof require !== "undefined" && require.main === module) demo();
